import tailwindcss from '@tailwindcss/vite';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  return {
    plugins: [tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      rollupOptions: {
        input: {
          main: path.resolve(__dirname, 'index.html'),
          services: path.resolve(__dirname, 'services.html'),
          portfolio: path.resolve(__dirname, 'portfolio.html'),
          portfolioDetail: path.resolve(__dirname, 'portfolio-detail.html'),
          about: path.resolve(__dirname, 'about.html'),
          businessAnalysis: path.resolve(__dirname, 'business-analysis.html'),
          projects: path.resolve(__dirname, 'projects.html'),
          blog: path.resolve(__dirname, 'blog.html'),
          products: path.resolve(__dirname, 'products.html'),
          contact: path.resolve(__dirname, 'contact.html'),
        },
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
