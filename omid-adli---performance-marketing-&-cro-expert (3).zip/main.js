/* ==========================================================================
   MAIN JAVASCRIPT - OMID ADLI PERSONAL BRAND WEBSITE
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initNavbar();
  initScrollReveals();
  initSparkles();
  initChecklist();
  initFilterPills();
  initBlogSearch();
  initContactForm();
});

/* --------------------------------------------------------------------------
   1. Theme Management (Dark / Light)
   -------------------------------------------------------------------------- */
function initTheme() {
  const themeToggleBtns = document.querySelectorAll('.theme-toggle-btn');
  const savedTheme = localStorage.getItem('theme') || 'dark';

  if (savedTheme === 'light') {
    document.body.classList.add('light-theme');
    updateToggleIcons('light');
  } else {
    document.body.classList.remove('light-theme');
    updateToggleIcons('dark');
  }

  themeToggleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const isLight = document.body.classList.toggle('light-theme');
      const newTheme = isLight ? 'light' : 'dark';
      localStorage.setItem('theme', newTheme);
      updateToggleIcons(newTheme);
    });
  });
}

function updateToggleIcons(theme) {
  const themeToggleBtns = document.querySelectorAll('.theme-toggle-btn');
  const sunIcon = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>`;
  const moonIcon = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>`;

  themeToggleBtns.forEach(btn => {
    btn.innerHTML = theme === 'light' ? moonIcon : sunIcon;
    btn.setAttribute('title', theme === 'light' ? 'تغییر به حالت تاریک' : 'تغییر به حالت روشن');
  });
}

/* --------------------------------------------------------------------------
   2. Navbar & Mobile Menu
   -------------------------------------------------------------------------- */
function initNavbar() {
  const mobileToggle = document.querySelector('.mobile-toggle');
  const navLinks = document.querySelector('.nav-links');
  const hamburgerSvg = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>`;
  const closeSvg = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`;

  if (mobileToggle && navLinks) {
    mobileToggle.innerHTML = hamburgerSvg;
    mobileToggle.addEventListener('click', () => {
      navLinks.classList.toggle('mobile-open');
      mobileToggle.innerHTML = navLinks.classList.contains('mobile-open') ? closeSvg : hamburgerSvg;
    });
  }

  // Active Nav Link Detection
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  const allNavAnchors = document.querySelectorAll('.nav-link, .dropdown-item');

  allNavAnchors.forEach(a => {
    const href = a.getAttribute('href');
    if (href === currentPath || (currentPath === '' && href === 'index.html')) {
      a.classList.add('active');
    }
  });
}

/* --------------------------------------------------------------------------
   3. Scroll Reveal Animations
   -------------------------------------------------------------------------- */
function initScrollReveals() {
  const revealElements = document.querySelectorAll('.glass-card, .page-title, .page-subtitle, .stat-card, .process-card, .section-header');

  revealElements.forEach(el => el.classList.add('fade-up'));

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
      }
    });
  }, { threshold: 0.1 });

  revealElements.forEach(el => observer.observe(el));
}

/* --------------------------------------------------------------------------
   4. Background Sparkle Particles
   -------------------------------------------------------------------------- */
function initSparkles() {
  const bgBlobs = document.querySelector('.bg-blobs');
  if (!bgBlobs) return;

  for (let i = 0; i < 20; i++) {
    const sparkle = document.createElement('div');
    sparkle.className = 'sparkle-particle';
    sparkle.style.top = `${Math.random() * 100}%`;
    sparkle.style.left = `${Math.random() * 100}%`;
    sparkle.style.animationDelay = `${Math.random() * 3}s`;
    sparkle.style.animationDuration = `${2 + Math.random() * 3}s`;
    bgBlobs.appendChild(sparkle);
  }
}

/* --------------------------------------------------------------------------
   5. Interactive Checklist (Business Analysis Page)
   -------------------------------------------------------------------------- */
function initChecklist() {
  const checklistItems = document.querySelectorAll('.checklist-item');
  checklistItems.forEach(item => {
    item.addEventListener('click', () => {
      item.classList.toggle('checked');
      const box = item.querySelector('.check-box');
      if (box) {
        box.textContent = item.classList.contains('checked') ? '✓' : '';
      }
    });
  });
}

/* --------------------------------------------------------------------------
   6. Portfolio & Blog Category Filter Pills
   -------------------------------------------------------------------------- */
function initFilterPills() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const filterableCards = document.querySelectorAll('[data-category]');

  if (filterBtns.length === 0) return;

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filterValue = btn.getAttribute('data-filter');

      filterableCards.forEach(card => {
        const cardCategory = card.getAttribute('data-category');
        if (filterValue === 'all' || cardCategory === filterValue || cardCategory.includes(filterValue)) {
          card.style.display = 'block';
          setTimeout(() => card.classList.add('active'), 50);
        } else {
          card.style.display = 'none';
        }
      });
    });
  });
}

/* --------------------------------------------------------------------------
   7. Blog Search Filter
   -------------------------------------------------------------------------- */
function initBlogSearch() {
  const searchInput = document.getElementById('blogSearchInput');
  const blogCards = document.querySelectorAll('.blog-card');

  if (!searchInput || blogCards.length === 0) return;

  searchInput.addEventListener('input', (e) => {
    const term = e.target.value.trim().toLowerCase();

    blogCards.forEach(card => {
      const text = card.textContent.toLowerCase();
      if (text.includes(term)) {
        card.style.display = 'block';
      } else {
        card.style.display = 'none';
      }
    });
  });
}

/* --------------------------------------------------------------------------
   8. Contact Form Simulator
   -------------------------------------------------------------------------- */
function initContactForm() {
  const contactForm = document.getElementById('contactForm');
  const formSuccess = document.getElementById('formSuccessMessage');

  if (!contactForm) return;

  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const submitBtn = contactForm.querySelector('button[type="submit"]');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = 'در حال ارسال...';
    }

    setTimeout(() => {
      contactForm.reset();
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = 'ارسال پیام و ثبت درخواست';
      }

      if (formSuccess) {
        formSuccess.style.display = 'block';
        formSuccess.classList.add('fade-up', 'active');
        setTimeout(() => {
          formSuccess.style.display = 'none';
        }, 6000);
      } else {
        alert('پیام شما با موفقیت ثبت شد! به زودی با شما تماس خواهم گرفت.');
      }
    }, 1200);
  });
}
