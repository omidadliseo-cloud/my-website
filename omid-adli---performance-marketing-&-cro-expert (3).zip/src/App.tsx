import React, { useState, useEffect } from 'react';
import { Theme, Page, CaseStudy } from './types';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { BackgroundBlobs } from './components/BackgroundBlobs';
import { QuickActionDock } from './components/QuickActionDock';
import { HomePage } from './pages/HomePage';
import { ServicesPage } from './pages/ServicesPage';
import { PortfolioPage } from './pages/PortfolioPage';
import { AboutPage } from './pages/AboutPage';
import { BlogPage } from './pages/BlogPage';
import { ContactPage } from './pages/ContactPage';


export default function App() {
  const [theme, setTheme] = useState<Theme>('dark');
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedCaseStudy, setSelectedCaseStudy] = useState<CaseStudy | null>(null);

  // Read initial page from URL hash on load & handle browser back/forward
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') as Page;
      const validPages: Page[] = ['home', 'services', 'portfolio', 'about', 'blog', 'contact'];
      if (validPages.includes(hash)) {
        setCurrentPage(hash);
      } else if (!hash) {
        setCurrentPage('home');
      }
    };

    // Initial check
    handleHashChange();

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Sync dark class on html tag for Tailwind and CSS
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.add('light');
      root.classList.remove('dark');
    }
  }, [theme]);

  const handleToggleTheme = () => {
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleNavigate = (page: Page) => {
    setCurrentPage(page);
    setSelectedCaseStudy(null);
    window.location.hash = page === 'home' ? '' : page;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCaseStudy = (study: CaseStudy | null) => {
    setSelectedCaseStudy(study);
    if (study && currentPage !== 'portfolio') {
      setCurrentPage('portfolio');
      window.location.hash = 'portfolio';
    }
  };

  return (
    <div className={`min-h-screen relative flex flex-col transition-colors duration-500 font-['Vazirmatn',sans-serif] ${
      theme === 'dark' 
        ? 'bg-[#0f0a2e] text-[#eae6ff]' 
        : 'bg-gradient-to-br from-[#ffd6f0] via-[#c9b6ff] to-[#b8d4ff] text-[#1a1240]'
    }`}>


      {/* Background Radial Blobs and Floating Sparkle Effects */}
      <BackgroundBlobs theme={theme} />

      {/* Glassmorphic Navigation Header */}
      <Navbar
        theme={theme}
        onToggleTheme={handleToggleTheme}
        currentPage={currentPage}
        onNavigate={handleNavigate}
      />

      {/* Main Content Area */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-8 relative z-10 pb-20">
        {currentPage === 'home' && (
          <HomePage
            theme={theme}
            onNavigate={handleNavigate}
            onSelectCaseStudy={handleSelectCaseStudy}
          />
        )}

        {currentPage === 'services' && (
          <ServicesPage
            theme={theme}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'portfolio' && (
          <PortfolioPage
            theme={theme}
            onNavigate={handleNavigate}
            selectedCaseStudy={selectedCaseStudy}
            onSelectCaseStudy={setSelectedCaseStudy}
          />
        )}

        {currentPage === 'about' && (
          <AboutPage
            theme={theme}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'blog' && (
          <BlogPage
            theme={theme}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'contact' && (
          <ContactPage
            theme={theme}
            onNavigate={handleNavigate}
          />
        )}
      </main>

      {/* Bottom Floating Quick Action Dock */}
      <QuickActionDock theme={theme} onNavigate={handleNavigate} />

      {/* Footer */}
      <Footer
        theme={theme}
        onNavigate={handleNavigate}
      />
    </div>
  );
}


