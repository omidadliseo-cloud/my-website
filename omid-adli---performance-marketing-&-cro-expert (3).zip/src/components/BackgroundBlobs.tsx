import React from 'react';
import { Theme } from '../types';

interface BackgroundBlobsProps {
  theme: Theme;
}

export const BackgroundBlobs: React.FC<BackgroundBlobsProps> = ({ theme }) => {
  const isDark = theme === 'dark';

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {/* Radial Background Gradients */}
      {isDark ? (
        <>
          {/* Dark Mode Glowing Radial Blobs */}
          <div 
            className="absolute -top-32 right-10 w-[500px] h-[500px] rounded-full blur-[130px] opacity-60 animate-pulse-glow"
            style={{ background: 'radial-gradient(circle, rgba(255, 79, 216, 0.45) 0%, rgba(15, 10, 46, 0) 70%)' }}
          />
          <div 
            className="absolute top-[25%] -left-32 w-[600px] h-[600px] rounded-full blur-[140px] opacity-50 animate-pulse-glow"
            style={{ 
              background: 'radial-gradient(circle, rgba(76, 141, 255, 0.45) 0%, rgba(15, 10, 46, 0) 70%)',
              animationDelay: '2s' 
            }}
          />
          <div 
            className="absolute top-[60%] right-[-100px] w-[550px] h-[550px] rounded-full blur-[130px] opacity-45 animate-pulse-glow"
            style={{ 
              background: 'radial-gradient(circle, rgba(92, 225, 230, 0.35) 0%, rgba(15, 10, 46, 0) 70%)',
              animationDelay: '4s'
            }}
          />
          <div 
            className="absolute bottom-[-100px] left-[20%] w-[650px] h-[650px] rounded-full blur-[150px] opacity-55"
            style={{ background: 'radial-gradient(circle, rgba(157, 78, 221, 0.35) 0%, rgba(15, 10, 46, 0) 70%)' }}
          />
          
          {/* Subtle Grid overlay for 3D depth */}
          <div 
            className="absolute inset-0 opacity-[0.07]"
            style={{
              backgroundImage: `linear-gradient(rgba(255, 255, 255, 0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.2) 1px, transparent 1px)`,
              backgroundSize: '60px 60px'
            }}
          />
        </>
      ) : (
        <>
          {/* Light Mode Soft Pastel Gradient Blobs */}
          <div 
            className="absolute -top-20 right-[-50px] w-[600px] h-[600px] rounded-full blur-[120px] opacity-70 animate-pulse-glow"
            style={{ background: 'radial-gradient(circle, rgba(255, 214, 240, 0.85) 0%, rgba(255, 255, 255, 0) 70%)' }}
          />
          <div 
            className="absolute top-[30%] -left-20 w-[650px] h-[650px] rounded-full blur-[140px] opacity-75 animate-pulse-glow"
            style={{ 
              background: 'radial-gradient(circle, rgba(201, 182, 255, 0.75) 0%, rgba(255, 255, 255, 0) 70%)',
              animationDelay: '2.5s'
            }}
          />
          <div 
            className="absolute top-[65%] right-10 w-[550px] h-[550px] rounded-full blur-[130px] opacity-70 animate-pulse-glow"
            style={{ 
              background: 'radial-gradient(circle, rgba(184, 212, 255, 0.8) 0%, rgba(255, 255, 255, 0) 70%)',
              animationDelay: '4.5s'
            }}
          />
          
          {/* Subtle dots pattern for light mode */}
          <div 
            className="absolute inset-0 opacity-[0.12]"
            style={{
              backgroundImage: 'radial-gradient(#4c8dff 1px, transparent 1px)',
              backgroundSize: '32px 32px'
            }}
          />
        </>
      )}

      {/* Floating Sparkle Stars */}
      <div className="absolute top-[12%] left-[15%] w-3 h-3 text-cyan-400 opacity-60 animate-float">✦</div>
      <div className="absolute top-[28%] right-[12%] w-4 h-4 text-violet-400 opacity-70 animate-float-delayed">★</div>
      <div className="absolute top-[48%] left-[8%] w-3 h-3 text-indigo-400 opacity-50 animate-float">✦</div>
      <div className="absolute top-[72%] right-[18%] w-4 h-4 text-cyan-300 opacity-65 animate-float-delayed">✧</div>
      <div className="absolute top-[88%] left-[25%] w-3 h-3 text-violet-300 opacity-60 animate-float">★</div>
    </div>
  );
};
