import React from 'react';
import { Theme, Page } from '../types';
import { PERSONAL_INFO } from '../data/content';
import { ArrowUp, Send, Mail, Linkedin, PhoneCall, Sparkles, CheckCircle2 } from 'lucide-react';

interface FooterProps {
  theme: Theme;
  onNavigate: (page: Page) => void;
}

export const Footer: React.FC<FooterProps> = ({ theme, onNavigate }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full px-4 sm:px-8 pt-16 pb-12 mt-20 relative z-10">
      <div className="max-w-7xl mx-auto rounded-[36px] bg-[#0f0a2e]/90 backdrop-blur-2xl border border-white/15 p-8 md:p-12 text-white shadow-[0_20px_60px_rgba(0,0,0,0.5)]">
        {/* Top Row: Logo, Bio & Socials */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-12 border-b border-white/10">
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#8b5cf6] via-[#4c8dff] to-[#5ce1e6] p-[2px]">
                <div className="w-full h-full rounded-[14px] bg-[#0f0a2e] flex items-center justify-center font-black text-xl text-white">
                  <span className="gradient-text">OA</span>
                </div>
              </div>
              <div>
                <h3 className="font-black text-xl text-white">امید عدلی</h3>
                <p className="text-xs text-[#5ce1e6] font-medium">Performance Marketing & CRO Expert</p>
              </div>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed max-w-md">
              {PERSONAL_INFO.bio}
            </p>

            {/* Live Status Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>{PERSONAL_INFO.availability}</span>
            </div>
          </div>

          {/* Nav Links Column */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="font-bold text-sm text-white border-r-2 border-[#8b5cf6] pr-2">دسترسی سریع</h4>
            <ul className="space-y-2 text-sm text-slate-300">
              <li>
                <button onClick={() => onNavigate('home')} className="hover:text-[#5ce1e6] transition-colors">
                  صفحه اصلی
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('services')} className="hover:text-[#5ce1e6] transition-colors">
                  خدمات تخصصی پاداش‌محور
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('portfolio')} className="hover:text-[#5ce1e6] transition-colors">
                  کیس‌استاندی‌ها & نمونه‌کارها
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-[#5ce1e6] transition-colors">
                  درباره من و سوابق
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('blog')} className="hover:text-[#5ce1e6] transition-colors">
                  مقالات و تحلیل‌های CRO
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('contact')} className="hover:text-[#5ce1e6] transition-colors">
                  فرم مشاوره اختصاصی
                </button>
              </li>
            </ul>
          </div>

          {/* Socials & Contact Chips */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="font-bold text-sm text-white border-r-2 border-[#4c8dff] pr-2">شبکه‌های اجتماعی و ارتباط مستقیم</h4>
            <div className="flex flex-wrap gap-2">
              <a
                href={`https://t.me/${PERSONAL_INFO.telegram.replace('@', '')}`}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-[#4c8dff]/20 border border-white/10 hover:border-[#4c8dff]/50 text-xs text-slate-200 transition-all flex items-center gap-2"
              >
                <Send className="w-4 h-4 text-[#5ce1e6]" />
                <span>تلگرام</span>
              </a>

              <a
                href={PERSONAL_INFO.linkedin}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-[#4c8dff]/20 border border-white/10 hover:border-[#4c8dff]/50 text-xs text-slate-200 transition-all flex items-center gap-2"
              >
                <Linkedin className="w-4 h-4 text-[#4c8dff]" />
                <span>لینکدین</span>
              </a>

              <a
                href={`mailto:${PERSONAL_INFO.email}`}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-[#8b5cf6]/20 border border-white/10 hover:border-[#8b5cf6]/50 text-xs text-slate-200 transition-all flex items-center gap-2"
              >
                <Mail className="w-4 h-4 text-[#8b5cf6]" />
                <span>ایمیل مستقیم</span>
              </a>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
              <span className="text-[11px] text-slate-400">آدرس ایمیل کاری:</span>
              <div className="font-mono text-xs text-white dir-ltr text-right select-all">{PERSONAL_INFO.email}</div>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Copyright + Scroll to top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            © {new Date().getFullYear()} Omid Adli. تمامی حقوق مادی و معنوی محفوظ است. طراحی با بالاترین استانداردهای SaaS و CRO.
          </div>

          <button
            onClick={scrollToTop}
            className="p-3 rounded-2xl bg-white/10 hover:bg-gradient-to-r hover:from-[#1d4ed8] hover:to-[#3b82f6] text-white transition-all duration-300 shadow-lg flex items-center gap-2 group"
          >
            <span>بازگشت به بالا</span>
            <ArrowUp className="w-4 h-4 group-hover:-translate-y-1 transition-transform" />
          </button>
        </div>
      </div>
    </footer>
  );
};
