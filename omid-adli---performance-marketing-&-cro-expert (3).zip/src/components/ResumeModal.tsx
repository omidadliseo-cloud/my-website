import React from 'react';
import { Theme } from '../types';
import { X, Download, Award, Briefcase, GraduationCap, CheckCircle2, Sparkles, Building2, BookOpen, Star } from 'lucide-react';
import { PERSONAL_INFO, TIMELINE, SELECT_PROJECTS, EDUCATION_AND_COURSES, ALL_SKILLS_LIST, OTHER_COLLABORATIONS } from '../data/content';

interface ResumeModalProps {
  theme: Theme;
  onClose: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ theme, onClose }) => {
  const isDark = theme === 'dark';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-xl overflow-y-auto">
      <div className={`relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-[40px] p-6 sm:p-10 border shadow-2xl ${
        isDark ? 'bg-[#1a1240] border-white/20 text-white' : 'bg-white border-slate-200 text-slate-900'
      }`}>
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 left-6 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Profile */}
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 pb-8 border-b border-white/10">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-[#8b5cf6] via-[#4c8dff] to-[#5ce1e6] p-1 shrink-0 shadow-lg">
            <div className={`w-full h-full rounded-[20px] flex items-center justify-center font-black text-2xl ${
              isDark ? 'bg-[#0f0a2e] text-white' : 'bg-white text-[#1a1240]'
            }`}>
              OA
            </div>
          </div>

          <div className="text-center sm:text-right space-y-2 flex-1">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <h2 className="text-2xl sm:text-3xl font-black">{PERSONAL_INFO.name}</h2>
              <a
                href={`mailto:${PERSONAL_INFO.email}`}
                className="glow-btn px-5 py-2.5 rounded-full text-xs font-bold text-white flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>ارتباط مستقیم / رزومه</span>
              </a>
            </div>

            <p className="text-xs font-bold text-[#5ce1e6]">{PERSONAL_INFO.title}</p>
            <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
              {PERSONAL_INFO.bio}
            </p>
          </div>
        </div>

        {/* Work Experiences */}
        <div className="py-6 space-y-6">
          <div className="flex items-center gap-2 text-sm font-black text-[#8b5cf6]">
            <Briefcase className="w-5 h-5" />
            <span>سوابق شغلی (Work Experience)</span>
          </div>

          <div className="space-y-4 text-xs">
            {TIMELINE.map((exp, idx) => (
              <div key={idx} className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2 font-bold text-sm text-white">
                  <span>{exp.title} — <span className="text-[#5ce1e6]">{exp.company}</span></span>
                  <span className="text-xs text-slate-400 font-mono">{exp.year}</span>
                </div>
                <p className="text-slate-300 leading-relaxed">{exp.description}</p>
                <div className="pt-2 flex items-center gap-2 font-bold text-emerald-400">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>دستاوردها: {exp.achievement}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Projects */}
        <div className="py-6 border-t border-white/10 space-y-4">
          <div className="flex items-center gap-2 text-sm font-black text-[#5ce1e6]">
            <Star className="w-5 h-5" />
            <span>پروژه‌های منتخب</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {SELECT_PROJECTS.map((proj, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-1">
                <div className="flex items-center justify-between font-bold text-white">
                  <span>{proj.title}</span>
                  <span className="text-[10px] text-slate-400">{proj.date}</span>
                </div>
                <p className="text-[#5ce1e6] text-[11px]">{proj.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Other Collaborations */}
        <div className="py-6 border-t border-white/10 space-y-4">
          <div className="flex items-center gap-2 text-sm font-black text-[#4c8dff]">
            <Building2 className="w-5 h-5" />
            <span>سایر همکاری‌ها</span>
          </div>

          <div className="flex flex-wrap gap-2 text-xs">
            {OTHER_COLLABORATIONS.map((collab, idx) => (
              <div key={idx} className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2">
                <span className="font-bold text-white">{collab.company}</span>
                <span className="text-slate-400">— {collab.role}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Education & Courses */}
        <div className="py-6 border-t border-white/10 space-y-4">
          <div className="flex items-center gap-2 text-sm font-black text-amber-400">
            <GraduationCap className="w-5 h-5" />
            <span>تحصیلات و دوره‌ها</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="space-y-2">
              <h4 className="font-bold text-white">تحصیلات:</h4>
              {EDUCATION_AND_COURSES.education.map((edu, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1">
                  <div className="font-bold text-white">{edu.title}</div>
                  <div className="text-slate-400">{edu.institute} · {edu.year} · {edu.grade}</div>
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <h4 className="font-bold text-white">دوره‌های تخصصی:</h4>
              {EDUCATION_AND_COURSES.courses.map((crs, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1">
                  <div className="font-bold text-[#5ce1e6]">{crs.title}</div>
                  <div className="text-slate-400">{crs.provider} · {crs.date}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="pt-6 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-bold text-white"
          >
            بستن رزومه
          </button>
        </div>
      </div>
    </div>
  );
};
