import React, { useState } from 'react';
import { Theme, Page } from '../types';
import { Sun, Moon, Menu, X, Sparkles, MessageSquare, ArrowUpLeft } from 'lucide-react';

interface NavbarProps {
  theme: Theme;
  onToggleTheme: () => void;
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  theme,
  onToggleTheme,
  currentPage,
  onNavigate
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isDark = theme === 'dark';

  const navItems: { id: Page; label: string }[] = [
    { id: 'home', label: 'صفحه اصلی' },
    { id: 'services', label: 'خدمات تخصصی' },
    { id: 'portfolio', label: 'نمونه‌کارها' },
    { id: 'about', label: 'درباره من' },
    { id: 'blog', label: 'مقالات' },
    { id: 'contact', label: 'تماس و مشاوره' }
  ];

  const handleNavClick = (page: Page) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-50 w-full px-4 sm:px-8 py-3">
      <div className={`max-w-7xl mx-auto rounded-3xl transition-all duration-300 backdrop-blur-xl border px-4 sm:px-6 py-3 flex items-center justify-between ${
        isDark 
          ? 'bg-[#1a1240]/75 border-white/15 shadow-[0_10px_30px_rgba(0,0,0,0.4)]' 
          : 'bg-white/80 border-white/90 shadow-[0_10px_30px_rgba(76,141,255,0.12)]'
      }`}>
        {/* Logo & Brand */}
        <button 
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 text-right group focus:outline-none"
        >
          <div className="relative w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#4c8dff] via-[#8b5cf6] to-[#5ce1e6] p-[2px] transition-transform duration-300 group-hover:scale-105 group-hover:rotate-3 shadow-md shadow-violet-500/20">
            <div className={`w-full h-full rounded-[14px] flex items-center justify-center font-black text-lg ${
              isDark ? 'bg-[#0f0a2e] text-white' : 'bg-white text-[#1a1240]'
            }`}>
              <span className="gradient-text">OA</span>
            </div>
            <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-[#5ce1e6] animate-ping" />
          </div>

          <div>
            <div className={`font-black text-base sm:text-lg leading-tight ${isDark ? 'text-white' : 'text-[#1a1240]'}`}>
              امید عدلی
            </div>
            <div className="text-[11px] font-medium text-slate-400">
              Performance Marketing & CRO
            </div>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 bg-white/5 p-1.5 rounded-full border border-white/10">
          {navItems.map((item) => {
            const active = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-4 py-2 rounded-full text-xs font-bold transition-all duration-300 relative ${
                  active
                    ? 'text-white bg-gradient-to-r from-[#2563eb] to-[#3b82f6] shadow-md shadow-blue-500/25'
                    : isDark 
                      ? 'text-slate-300 hover:text-white hover:bg-white/10' 
                      : 'text-slate-700 hover:text-[#1a1240] hover:bg-slate-100'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Right Actions: Theme Toggle + Contact CTA Pill */}
        <div className="hidden sm:flex items-center gap-3">
          {/* Theme Switcher Toggle Switch */}
          <button
            onClick={onToggleTheme}
            aria-label="تغییر پوسته تاریک/روشن"
            className={`relative w-16 h-9 rounded-full p-1 transition-all duration-500 border flex items-center justify-between ${
              isDark 
                ? 'bg-[#0f0a2e] border-[#5ce1e6]/40 shadow-[0_0_15px_rgba(92,225,230,0.3)]' 
                : 'bg-amber-100/80 border-amber-300 shadow-[0_0_15px_rgba(251,191,36,0.3)]'
            }`}
          >
            <Sun className={`w-4 h-4 text-amber-500 z-10 transition-opacity ${isDark ? 'opacity-40' : 'opacity-100'}`} />
            <Moon className={`w-4 h-4 text-cyan-300 z-10 transition-opacity ${isDark ? 'opacity-100' : 'opacity-40'}`} />
            
            {/* Sliding Switch Knob */}
            <div
              className={`absolute top-1 w-7 h-7 rounded-full transition-transform duration-300 shadow-md ${
                isDark 
                  ? 'translate-x-[2px] bg-gradient-to-tr from-[#4c8dff] to-[#5ce1e6]' 
                  : 'translate-x-[-30px] bg-gradient-to-tr from-amber-400 to-orange-400'
              }`}
            />
          </button>

          {/* Contact Me CTA Pill Button */}
          <button
            onClick={() => handleNavClick('contact')}
            className="glow-btn px-5 py-2.5 rounded-full text-xs font-bold text-white flex items-center gap-2 group cursor-pointer"
          >
            <span>مشاوره و تماس</span>
            <ArrowUpLeft className="w-4 h-4 transition-transform group-hover:-translate-x-0.5 group-hover:-translate-y-0.5" />
          </button>
        </div>

        {/* Mobile Menu & Theme Toggle Buttons */}
        <div className="flex sm:hidden items-center gap-2">
          <button
            onClick={onToggleTheme}
            className={`p-2 rounded-xl border ${isDark ? 'bg-white/10 border-white/20 text-yellow-300' : 'bg-slate-100 border-slate-300 text-slate-800'}`}
          >
            {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`p-2 rounded-xl border ${isDark ? 'bg-white/10 border-white/20 text-white' : 'bg-slate-100 border-slate-300 text-slate-800'}`}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className={`sm:hidden mt-3 p-5 rounded-3xl backdrop-blur-2xl border transition-all duration-300 ${
          isDark 
            ? 'bg-[#1a1240]/95 border-white/20 shadow-2xl text-white' 
            : 'bg-white/95 border-slate-200 shadow-2xl text-slate-900'
        }`}>
          <div className="flex flex-col gap-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full text-right py-3 px-4 rounded-2xl text-sm font-bold transition-colors ${
                  currentPage === item.id
                    ? 'bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white'
                    : isDark ? 'hover:bg-white/10 text-slate-200' : 'hover:bg-slate-100 text-slate-800'
                }`}
              >
                {item.label}
              </button>
            ))}

            <div className="pt-3 border-t border-white/10 mt-2">
              <button
                onClick={() => handleNavClick('contact')}
                className="w-full glow-btn py-3.5 rounded-2xl text-sm font-bold text-white flex items-center justify-center gap-2"
              >
                <span>درخواست مشاوره اختصاصی</span>
                <ArrowUpLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
