import React, { useState } from 'react';
import { Theme, Page } from '../types';
import { Calendar, FileText, Send, Sparkles } from 'lucide-react';
import { ResumeModal } from './ResumeModal';

interface QuickActionDockProps {
  theme: Theme;
  onNavigate: (page: Page) => void;
}

export const QuickActionDock: React.FC<QuickActionDockProps> = ({ theme, onNavigate }) => {
  const isDark = theme === 'dark';
  const [showResume, setShowResume] = useState(false);

  return (
    <>
      <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-40 max-w-lg w-[92%] sm:w-auto">
        <div className={`p-2.5 sm:p-3 rounded-full border backdrop-blur-2xl transition-all duration-300 shadow-2xl flex items-center justify-between gap-2 sm:gap-3 ${
          isDark
            ? 'bg-[#1a1240]/90 border-white/20 text-white shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white/90 border-slate-300 text-slate-900 shadow-[0_20px_50px_rgba(76,141,255,0.2)]'
        }`}>
          {/* Quick Action 1: Calendar Booking */}
          <button
            onClick={() => {
              onNavigate('contact');
              window.scrollTo({ top: 300, behavior: 'smooth' });
            }}
            className="glow-btn px-3 py-2 sm:px-4 sm:py-2.5 rounded-full text-[11px] sm:text-xs font-bold text-white transition-all flex items-center gap-1.5"
          >
            <Calendar className="w-4 h-4 shrink-0" />
            <span className="hidden xs:inline sm:inline">رزرو جلسه</span>
          </button>

          {/* Quick Action 2: Resume */}
          <button
            onClick={() => setShowResume(true)}
            className="glow-btn px-3 py-2 sm:px-4 sm:py-2.5 rounded-full text-[11px] sm:text-xs font-bold text-white transition-all flex items-center gap-1.5"
          >
            <FileText className="w-4 h-4 shrink-0" />
            <span className="hidden xs:inline sm:inline">مشاهده رزومه</span>
          </button>

          {/* Quick Action 3: Main CTA */}
          <button
            onClick={() => onNavigate('contact')}
            className="glow-btn px-4 py-2 sm:px-5 sm:py-2.5 rounded-full text-[11px] sm:text-xs font-bold text-white shrink-0 flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>درخواست همکاری</span>
          </button>
        </div>
      </div>

      {/* Resume Modal */}
      {showResume && (
        <ResumeModal theme={theme} onClose={() => setShowResume(false)} />
      )}
    </>
  );
};
