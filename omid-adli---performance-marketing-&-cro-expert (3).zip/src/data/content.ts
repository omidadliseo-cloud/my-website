import { ServiceItem, CaseStudy, Testimonial, BlogPost, SkillTool, TimelineMilestone } from '../types';

export const PERSONAL_INFO = {
  name: 'امید عدلی',
  title: 'متخصص دیزاین و اجرای کمپین‌های تبلیغاتی | Performance Marketing & Growth Specialist',
  tagline: 'ساخت سیستم‌های بازاریابی داده‌محور، بهینه‌سازی Funnel و رشد قابل اندازه‌گیری شاخص‌های کلیدی (CRO, CTR, CPA)',
  bio: 'متخصص Performance Marketing & Growth با بیش از ۵ سال تجربه در طراحی، اجرا و بهینه‌سازی کمپین‌های تبلیغاتی، تحلیل داده، CRO و SEO. تمرکز اصلی من ساخت سیستم‌های بازاریابی داده‌محور است که از طریق بهینه‌سازی Funnel، پیاده‌سازی Tracking، تحلیل رفتار کاربران و بهبود مستمر عملکرد کمپین‌ها به رشد قابل اندازه‌گیری کسب‌وکار منجر می‌شوند. تجربه همکاری با برندهای فین‌تک، رمزارز، گردشگری و تجارت الکترونیک باعث شده بتوانم میان تحلیل داده، تصمیم‌گیری بازاریابی و اجرای عملیاتی ارتباط مؤثری ایجاد کنم.',
  experienceYears: '۵+ سال',
  campaignsCount: '۵۰+ کمپین',
  avgRoasBoost: '۳.۵٪ CTR',
  totalAdSpendManaged: '۵+ برند',
  availability: 'در دسترس برای همکاری ریموت و پروژه‌ای',
  email: 'contact@omidadli01.site',
  telegram: '@omidadli',
  whatsapp: '+989120000000',
  linkedin: 'https://linkedin.com/in/omidadli',
  instagram: 'https://instagram.com/omidadli.marketing',
  website: 'omidadli01.site',
  location: 'مشهد / تهران / ریموت'
};

export const SERVICES: ServiceItem[] = [
  {
    id: 'performance-marketing',
    title: 'پرفورمنس مارکتینگ & مدیریت کمپین',
    titleEn: 'Performance Marketing & Campaign Management',
    iconName: 'rocket',
    shortDesc: 'طراحی، اجرا و بهینه‌سازی کمپین‌های جذب کاربر با تمرکز بر کاهش CPA و افزایش بازدهی بودجه.',
    fullDesc: 'هدایت و اجرای کمپین‌های پرفورمنس مارکتینگ در بسترهای Google Ads، Meta Ads و TikTok Ads. ارزیابی دقیق کیفیت پابلیشرها با سیستم‌های Dynamic Scoring و هدف‌گیری هوشمند مخاطبان.',
    features: [
      'توسعه سیستم Publisher Dynamic Scoring جهت سنجش کیفیت ترافیک',
      'کاهش CPA و افزایش CTR کمپین‌ها (مانند ارتقا به ۳.۵٪ در ای‌ادز)',
      'بهینه‌سازی کمپین‌های Display Ads، Google Search و Retargeting',
      'استانداردسازی UTMها و سگمنت‌بندی دقیق مخاطبان'
    ],
    deliverables: ['گزارش‌دهی دقیق داده‌محور', 'بهینه‌سازی بیدینگ و بودجه', 'ارزیابی کیفیت ترافیک'],
    tags: ['Google Ads', 'Performance Marketing', 'Meta Ads', 'CPA Reduction']
  },
  {
    id: 'cro-optimization',
    title: 'بهینه‌سازی نرخ تبدیل (CRO) & تحلیل Funnel',
    titleEn: 'Conversion Rate Optimization & Funnel Analysis',
    iconName: 'target',
    shortDesc: 'شناسایی نقاط افت مسیر خرید، اجرای تست‌های A/B و افزایش نرخ تبدیل کاربران بدون افزایش بودجه.',
    fullDesc: 'طراحی و اجرای تست‌های A/B برای صفحات کلیدی و مسیرهای رزرو/خرید. تحلیل رفتار کاربران با GA4، Hotjar و Microsoft Clarity برای شناسایی دقیق چالش‌های UX و ارتقای conversion rate.',
    features: [
      'طراحی و اجرای تست‌های A/B بر روی صفحات کلیدی مسیر خرید',
      'تحلیل رفتار کاربران با GA4، Hotjar و Microsoft Clarity',
      'شناسایی نقاط ریزش در Funnel و تدوین Roadmap بهینه‌سازی UX',
      'افزایش نرخ تبدیل لندینگ‌پیج‌ها (رشد ۲۵٪ نرخ تبدیل در پروژه‌های قبلی)'
    ],
    deliverables: ['Roadmap بهبود تجربه کاربری', 'طراحی و تحلیل تست‌های A/B', 'گزارش‌های هیت‌مپ و رفتار کاربر'],
    tags: ['CRO', 'A/B Testing', 'GA4', 'Hotjar', 'Microsoft Clarity']
  },
  {
    id: 'tracking-analytics',
    title: 'معماری Tracking و آنالیتیکس داده‌ها (GTM & GA4)',
    titleEn: 'Tracking Architecture & Marketing Measurement',
    iconName: 'chart',
    shortDesc: 'پیاده‌سازی معماری ترکینگ، Event Tracking و افزایش دقت Attribution داده‌های بازاریابی.',
    fullDesc: 'طراحی و نگهداری ساختار Google Tag Manager برای Affiliate Marketing و کمپین‌های دیجیتال. اعتبارسنجی داده‌ها و پیاده‌سازی مدلسازی Attribution برای ارزیابی شفاف عملکرد کانال‌های جذب.',
    features: [
      'طراحی معماری Tracking برای Affiliate Marketing و جذب کاربر',
      'پیاده‌سازی و اعتبارسنجی ساختار Event Tracking در GTM',
      'افزایش دقت Attribution و شفاف‌سازی تحلیل کانال‌ها',
      'کاهش ۲۲٪ کلیک‌های نامعتبر از طریق مدل‌های ارزیابی کیفیت'
    ],
    deliverables: ['مستندسازی کامل Event Tracking', 'اتصال دقیق GTM و GA4', 'داشبوردهای تحلیلی کیفیت داده'],
    tags: ['Google Tag Manager', 'GA4', 'Event Tracking', 'Attribution']
  },
  {
    id: 'seo-growth',
    title: 'استراتژی سئو و رشد ارگانیک (SEO)',
    titleEn: 'SEO Strategy & Organic Growth',
    iconName: 'laptop',
    shortDesc: 'رساندن کلیدواژه‌های رقابتی به صفحه نخست گوگل، بهینه‌سازی ساختار و رشد پایدار ورودی.',
    fullDesc: 'تدوین استراتژی SEO هدفمند، لینک‌سازی ساختاریافته و بهبود Technical SEO. تجربه موفق رساندن کلیدواژه «قیمت میلگرد» به رتبه ۱ گوگل و کسب ۱۵ کلمه صفحه اول در حوزه رمزارز.',
    features: [
      'بهینه‌سازی Technical SEO و معماری محتوایی صفحات',
      'تحلیل Search Intent و ارتقای Snippetها جهت افزایش CTR',
      'تدوین استراتژی لینک‌سازی داخلی و خارجی برای کلمات پررقابت',
      'رشد ۵۰٪ ترافیک ارگانیک در حوزه‌های رمزارز و صنعتی'
    ],
    deliverables: ['کیوورد ریسرچ و نقشه محتوا', 'آنالیز فنی SEO', 'گزارش رتبه‌بندی و CTR'],
    tags: ['SEO Strategy', 'Technical SEO', 'Keyword Research', 'Google Rank 1']
  }
];

export const CASE_STUDIES: CaseStudy[] = [
  {
    id: 'dayan-performance',
    title: 'توسعه سیستم Publisher Scoring و بهینه‌سازی Funnel جذب کاربر',
    client: 'دایان (مشهد)',
    industry: 'Fintech',
    industryFa: 'پرفورمنس مارکتینگ',
    summary: 'توسعه سیستم Publisher Dynamic Scoring برای ارزیابی کیفیت پابلیشرها و افزایش دقت تصمیم‌گیری در کمپین‌ها.',
    thumbnailIcon: 'chart',
    heroColor: '#8b5cf6',
    featured: true,
    metrics: {
      roas: 'CPA Optimized',
      conversionRate: 'High Quality Leads',
      cacReduction: '-CPA'
    },
    metricsComparison: [
      { label: 'دقت ارزیابی کیفیت پابلیشرها', before: 'سنتی', after: 'Dynamic Scoring', growth: '+۱۰۰٪' },
      { label: 'کیفیت لیدهای دریافتی', before: 'متوسط', after: 'بسیار بالا', growth: '+۴۵٪' },
      { label: 'بهره‌وری بودجه تبلیغاتی', before: 'معمولی', after: 'حداکثری', growth: '+۳۵٪' }
    ],
    challenge: 'عدم وجود سنجه‌های دقیق برای سنجش کیفیت لیدهای ارسالی از سمت پابلیشرها و اتلاف بخشی از بودجه تبلیغاتی.',
    solution: 'طراحی سیستم امتیازدهی پویا (Publisher Scoring)، هدایت کمپین‌های جذب با تمرکز بر کاهش CPA و تحلیل مستمر KPIهای Funnel.',
    results: 'کاهش محسوس هزینه جذب لید مؤثر، ارتقای شفافیت تصمیم‌گیری‌ها و افزایش بهره‌وری کل بودجه.',
    tags: ['Publisher Scoring', 'CPA Reduction', 'Funnel Optimization', 'Lead Quality'],
    date: 'اکنون'
  },
  {
    id: 'iranbroker-tracking',
    title: 'طراحی معماری Tracking و افزایش دقت Attribution در Affiliate Marketing',
    client: 'ایران بروکر (مشهد)',
    industry: 'Fintech',
    industryFa: 'فین‌تک و رمزارز',
    summary: 'معماری جامع Tracking، پیاده‌سازی ساختار Event Tracking در GTM و بهینه‌سازی کمپین‌های Display Ads.',
    thumbnailIcon: 'rocket',
    heroColor: '#4c8dff',
    featured: true,
    metrics: {
      roas: 'High Attribution',
      conversionRate: 'Data Quality Up',
      cacReduction: 'Display Ads Opt'
    },
    metricsComparison: [
      { label: 'دقت مدل Attribution', before: 'محدود', after: 'شفاف و کامل', growth: '+۸۵٪' },
      { label: 'کیفیت داده‌های بازاریابی', before: 'همپوشانی', after: 'اعتبارسنجی‌شده', growth: '+۹۵٪' },
      { label: 'هزینه جذب کاربر (Display Ads)', before: 'بالا', after: 'بهینه‌شده', growth: '-۳۰٪' }
    ],
    challenge: 'عدم امکان تحلیل دقیق عملکرد کانال‌های مختلف جذب Affiliate و خطاهای همپوشانی در ترکینگ رویدادها.',
    solution: 'طراحی ساختار کامل GTM Event Tracking، اعتبارسنجی داده‌ها و بهینه‌سازی ساختاری کمپین‌های Display گوگل.',
    results: 'ایجاد شفافیت ۱۰۰٪ در تحلیل کانال‌های ورودی و کاهش هزینه جذب کاربر با بهبود کیفیت ترافیک.',
    tags: ['Tracking Architecture', 'Attribution Accuracy', 'GTM', 'Display Ads'],
    date: 'شهریور – دی ۱۴۰۴'
  },
  {
    id: 'eqamat24-cro',
    title: 'بهینه‌سازی نرخ تبدیل (CRO) مسیر رزرو و اجرای تست‌های A/B',
    client: 'اقامت ۲۴ (مشهد)',
    industry: 'Travel',
    industryFa: 'گردشگری و سفر',
    summary: 'تحلیل رفتار کاربران با GA4، Hotjar و Clarity و تدوین Roadmap بهینه‌سازی UX مسیر رزرو.',
    thumbnailIcon: 'target',
    heroColor: '#5ce1e6',
    featured: true,
    metrics: {
      roas: 'CRO Boosted',
      conversionRate: '+A/B Tested',
      cacReduction: '-Funnel Drops'
    },
    metricsComparison: [
      { label: 'نرخ تبدیل مسیر رزرو', before: 'پایه', after: 'ارتقا یافته', growth: '+۲۸٪' },
      { label: 'شناسایی نقاط افت Funnel', before: 'تخمینی', after: 'تحلیل داده‌محور', growth: '+۱۰۰٪' },
      { label: 'تست‌های موفق A/B', before: '۰', after: 'چندین فاز موفق', growth: '+A/B' }
    ],
    challenge: 'وجود نقاط افت (Drop-off) در مراحل نهایی مسیر رزرو هتل و هدررفت ترافیک ورودی سایت.',
    solution: 'بررسی دقیق رکوردهای رفتاری در Hotjar و Microsoft Clarity، طراحی تست‌های A/B برای صفحات کلیدی و همکاری با تیم محصول.',
    results: 'اصلاح تجربه کاربری، کاهش ریزش کاربران در مسیر خرید و افزایش نرخ تبدیل کل سیستم رزرو.',
    tags: ['CRO', 'GA4', 'Microsoft Clarity', 'Hotjar', 'A/B Testing'],
    date: 'خرداد – شهریور ۱۴۰۴'
  },
  {
    id: 'eads-campaigns',
    title: 'افزایش CTR از ۱.۲٪ به ۳.۵٪ و رشد ۲۵٪ نرخ تبدیل برای ۵ برند معتبر',
    client: 'ای ادز (تهران)',
    industry: 'SaaS',
    industryFa: 'آژانس تبلیغاتی',
    summary: 'مدیریت کمپین‌های پرفورمنس مارکتینگ در Google Ads، Meta Ads و TikTok Ads و استانداردسازی UTMها.',
    thumbnailIcon: 'laptop',
    heroColor: '#9d4edd',
    featured: false,
    metrics: {
      roas: '3.5% CTR',
      conversionRate: '+25% Conv Rate',
      cacReduction: '5 Brands Managed'
    },
    metricsComparison: [
      { label: 'میانگین کلیک به نمایش (CTR)', before: '۱.۲٪', after: '۳.۵٪', growth: '+۱۹۱٪' },
      { label: 'افزایش نرخ تبدیل لندینگ‌پیج‌ها', before: 'پایه', after: 'بهینه‌شده', growth: '+۲۵٪' }
    ],
    challenge: 'CTR پایین و ساختار غیراستاندارد UTMها که تحلیل دقیق کمپین‌ها را ناممکن ساخته بود.',
    solution: 'بازطراحی ساختار کمپین‌ها، هدف‌گیری دقیق‌تر مخاطبان و همکاری مستقیم با تیم طراحی برای بهبود لندینگ‌ها.',
    results: 'رشد چشمگیر تعامل مخاطبان، افزایش ۲۵ درصدی تبدیل‌ها و مدیریت موفق بودجه ۵ برند همزمان.',
    tags: ['Google Ads', 'Meta Ads', 'TikTok Ads', 'CTR Boost'],
    date: 'مرداد ۱۴۰۲ – بهمن ۱۴۰۳'
  }
];

export const STATS = [
  { value: '۵+', label: 'سال تجربه تخصصی', subtext: 'در پرفورمنس مارکتینگ و CRO', icon: 'award' },
  { value: '+۵۰', label: 'کمپین موفق ویدئویی و کلیکی', subtext: 'در آپارات، اینستاگرام، تلگرام و گوگل', icon: 'rocket' },
  { value: '۳.۵٪', label: 'میانگین CTR ارتقایافته', subtext: 'رشد از ۱.۲٪ به ۳.۵٪ در کمپین‌ها', icon: 'trending-up' },
  { value: 'رتبه ۱', label: 'گوگل در کلمات پررقابت', subtext: 'مانند «قیمت میلگرد» و کلمات رمزارز', icon: 'layers' }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    clientName: 'تیم پرفورمنس مارکتینگ',
    clientRole: 'مدیر ارشد محصول و رشد',
    company: 'دایان',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    quote: 'پیاده‌سازی سیستم Publisher Dynamic Scoring توسط امید، دقت ما در ارزیابی ترافیک ورودی را به شدت بالا برد و باعث شد لیدهای بسیار باکیفیت‌تری جذب کنیم.',
    metricHighlight: 'بهینه‌سازی کامل CPA'
  },
  {
    id: '2',
    clientName: 'تیم فنی و مارکتینگ',
    clientRole: 'مدیر ارشد بازاریابی',
    company: 'ایران بروکر',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    quote: 'معماری ترکینگ دقیق و اعتبارسنجی GTM که امید طراحی کرد، شفافیت کاملی در ارزیابی کانال‌های Affiliate به ما داد.',
    metricHighlight: 'دقت بالای Attribution'
  },
  {
    id: '3',
    clientName: 'تیم محصول و CRO',
    clientRole: 'سرپرست تیم بهینه‌سازی',
    company: 'اقامت ۲۴',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    quote: 'اجرای دقیق تست‌های A/B و تحلیل رفتار کاربران در GA4 و Clarity توسط امید، نقش مهمی در کاهش نقاط افت مسیر رزرو داشت.',
    metricHighlight: 'رشد ۲۸٪ نرخ تبدیل رزرو'
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'cro-funnel-guide',
    title: 'اصول بهینه‌سازی نرخ تبدیل (CRO) و کاهش نقاط افت در Funnel رزرو و خرید',
    excerpt: 'چگونه با تحلیل رفتار کاربران در Hotjar و GA4 و اجرای تست‌های A/B، فروش سایت را ارتقا دهیم؟',
    content: `شناسایی نقاط ریزش کاربران در مسیر خرید یا رزرو، کلیدی‌ترین گام در افزایش سودآوری است. در این مقاله فریم‌ورک‌های کاربردی CRO را بررسی می‌کنیم...`,
    category: 'CRO',
    categoryFa: 'بهینه‌سازی نرخ تبدیل',
    date: 'شهریور ۱۴۰۴',
    readTime: '۷ دقیقه مطالعه',
    author: 'امید عدلی',
    imageIcon: 'target',
    featured: true
  },
  {
    id: 'tracking-attribution-gtm',
    title: 'معماری دقیق Tracking در GTM و افزایش دقت Attribution در کمپین‌های بازاریابی',
    excerpt: 'چگونه با پیاده‌سازی Event Tracking استاندارد و UTMها، گزارش‌هایی کاملاً شفاف از کانال‌های جذب بسازیم؟',
    content: `بدون ترکینگ دقیق رویدادها، ارزیابی بازدهی کمپین‌ها غیرممکن است. در این نوشتار نحوه اعتبارسنجی داده‌ها در GTM را آموزش می‌دهیم...`,
    category: 'Analytics',
    categoryFa: 'آنالیتیکس و ترکینگ',
    date: 'مرداد ۱۴۰۴',
    readTime: '۱۰ دقیقه مطالعه',
    author: 'امید عدلی',
    imageIcon: 'chart',
    featured: false
  },
  {
    id: 'publisher-scoring-cpa',
    title: 'کاهش CPA و سنجش کیفیت ترافیک با الگوریتم‌های Publisher Dynamic Scoring',
    excerpt: 'رویکردی نوآورانه در پرفورمنس مارکتینگ برای شناسایی کلیک‌های نامعتبر و ارتقای کیفیت لیدها.',
    content: `در کمپین‌های بزرگ جذب کاربر، سنجش کیفیت ورودی‌ها اهمیت حیاتی دارد. مدل‌های Dynamic Scoring به شما کمک می‌کنند بودجه را در کانال‌های برنده متمرکز کنید...`,
    category: 'Performance',
    categoryFa: 'پرفورمنس مارکتینگ',
    date: 'تیر ۱۴۰۴',
    readTime: '۶ دقیقه مطالعه',
    author: 'امید عدلی',
    imageIcon: 'rocket',
    featured: false
  }
];

export const SKILLS_TOOLS: SkillTool[] = [
  { name: 'Google Ads', category: 'Ads', icon: 'google', proficiency: 98 },
  { name: 'Meta Ads', category: 'Ads', icon: 'meta', proficiency: 92 },
  { name: 'TikTok Ads', category: 'Ads', icon: 'tiktok', proficiency: 88 },
  { name: 'Google Analytics 4 (GA4)', category: 'Analytics', icon: 'ga4', proficiency: 96 },
  { name: 'Google Tag Manager (GTM)', category: 'Analytics', icon: 'gtm', proficiency: 95 },
  { name: 'Hotjar & Clarity', category: 'CRO', icon: 'hotjar', proficiency: 94 },
  { name: 'A/B Testing & VWO', category: 'CRO', icon: 'cro', proficiency: 92 },
  { name: 'WordPress & Elementor', category: 'Tech', icon: 'wordpress', proficiency: 90 },
  { name: 'HTML & CSS', category: 'Tech', icon: 'code', proficiency: 85 },
  { name: 'AI & Prompt Engineering', category: 'Tech', icon: 'ai', proficiency: 90 }
];

export const ALL_SKILLS_LIST = {
  hard: [
    { title: 'Growth & Performance Marketing', tags: ['Performance Strategy', 'Customer Acquisition', 'Growth Marketing', 'Campaign Optimization', 'Lead Generation', 'Audience Segmentation', 'Budget Optimization', 'Funnel Optimization'] },
    { title: 'Marketing Analytics & CRO', tags: ['KPI Design', 'Marketing Analytics', 'Dashboard Design', 'A/B Testing', 'Conversion Rate Optimization (CRO)', 'Landing Page Optimization', 'Funnel Analysis', 'UX Optimization'] },
    { title: 'Tracking & Measurement', tags: ['Google Tag Manager (GTM)', 'Event Tracking', 'Google Analytics 4 (GA4)', 'UTM Strategy', 'Conversion Tracking', 'Attribution Modeling'] },
    { title: 'Paid Media', tags: ['TikTok Ads', 'Meta Ads', 'Google Ads', 'Retargeting Strategy', 'Display Advertising'] },
    { title: 'SEO', tags: ['On-page SEO', 'Technical SEO', 'Keyword Research & Strategy', 'Search Intent Analysis', 'Content Optimization', 'Internal Linking Strategy'] },
    { title: 'Web Development & Landing Pages', tags: ['WordPress Website Development', 'Elementor', 'Landing Page Development', 'Basic HTML & CSS'] },
    { title: 'AI & Productivity', tags: ['AI-assisted Research', 'Prompt Engineering', 'Workflow Optimization'] }
  ],
  soft: [
    { title: 'تفکر راهبردی و تحلیلی', tags: ['تفکر راهبردی', 'تفکر تحلیلی', 'تفکر نقادانه', 'تصمیم‌گیری مبتنی بر داده', 'حل مسئله'] },
    { title: 'همکاری و ارتباطات', tags: ['ارتباط مؤثر', 'همکاری بین‌تیمی', 'مدیریت ذینفعان', 'انتقال و به‌اشتراک‌گذاری دانش'] },
    { title: 'اجرا و بهره‌وری', tags: ['هماهنگی و پیگیری پروژه‌ها', 'مدیریت زمان', 'اولویت‌بندی وظایف', 'دقت و توجه به جزئیات', 'نتیجه‌گرایی'] },
    { title: 'سازگاری و رشد حرفه‌ای', tags: ['سازگاری با تغییر', 'یادگیری مستمر', 'ذهنیت رشد', 'مسئولیت‌پذیری و مالکیت کارها (Ownership)'] }
  ]
};

export const TIMELINE: TimelineMilestone[] = [
  {
    year: 'اکنون',
    title: 'کارشناس پرفورمنس مارکتینگ',
    company: 'دایان | مشهد',
    description: 'توسعه و پیاده‌سازی سیستم Publisher Dynamic Scoring برای ارزیابی کیفیت پابلیشرها و افزایش دقت تصمیم‌گیری در کمپین‌ها. هدایت طراحی، اجرا و بهینه‌سازی کمپین‌های جذب کاربر با تمرکز بر کاهش CPA و بهبود بهره‌وری بودجه.',
    achievement: 'کاهش CPA، افزایش کیفیت لید، پیاده‌سازی سیستم Publisher Scoring'
  },
  {
    year: 'شهریور – دی ۱۴۰۴',
    title: 'کارشناس پرفورمنس مارکتینگ',
    company: 'ایران بروکر | مشهد',
    description: 'طراحی معماری Tracking برای Affiliate Marketing با هدف افزایش دقت Attribution. پیاده‌سازی و اعتبارسنجی ساختار GTM و Event Tracking و بهینه‌سازی کمپین‌های Display گوگل.',
    achievement: 'معماری جامع Tracking، افزایش دقت Attribution، بهبود کیفیت داده‌ها'
  },
  {
    year: 'خرداد – شهریور ۱۴۰۴',
    title: 'کارشناس بهینه‌سازی نرخ تبدیل (CRO)',
    company: 'اقامت ۲۴ | مشهد',
    description: 'طراحی و اجرای تست‌های A/B برای صفحات کلیدی مسیر رزرو. تحلیل رفتار کاربران با GA4، Microsoft Clarity و Hotjar و تدوین Roadmap بهینه‌سازی تجربه کاربری.',
    achievement: 'افزایش نرخ تبدیل مسیر رزرو، اجرای تست‌های A/B، تحلیل نقاط افت Funnel'
  },
  {
    year: 'مرداد ۱۴۰۲ – بهمن ۱۴۰۳',
    title: 'مدیر کمپین (Campaign Manager)',
    company: 'ای ادز | تهران',
    description: 'مدیریت و بهینه‌سازی کمپین‌های Performance Marketing برای ۵ برند در Google Ads، Meta Ads و TikTok Ads. ارتقای CTR از ۱.۲٪ به ۳.۵٪ و استانداردسازی UTMها.',
    achievement: 'افزایش CTR به ۳.۵٪، رشد ۲۵٪ نرخ تبدیل لندینگ‌پیج‌ها، مدیریت ۵ برند'
  },
  {
    year: 'دی ۱۴۰۲ – تیر ۱۴۰۳',
    title: 'مدیر کمپین (Campaign Manager)',
    company: 'فست کلیک | تهران',
    description: 'طراحی و اجرای بیش از ۵۰ کمپین ویدئویی در آپارات، اینستاگرام و تلگرام. توسعه مدل ارزیابی کیفیت ترافیک (کاهش ۲۲٪ کلیک نامعتبر) و کاهش ۳۰٪ CPA در کمپین‌های Retargeting.',
    achievement: 'کاهش ۳۰٪ CPA، کاهش ۲۲٪ کلیک‌های نامعتبر، اجرای +۵۰ کمپین ویدئویی'
  },
  {
    year: 'خرداد ۱۴۰۱ – خرداد ۱۴۰۲',
    title: 'کارشناس سئو',
    company: 'آهن آنلاین | تهران',
    description: 'رساندن کلیدواژه «قیمت میلگرد» به رتبه نخست گوگل از طریق لینک‌سازی هدفمند و بهینه‌سازی ساختار صفحات. افزایش ۳۰٪ ترافیک کلیدواژه‌های استراتژیک و ارتقای Snippetها.',
    achievement: 'رتبه ۱ گوگل در «قیمت میلگرد»، رشد ۳۰٪ ترافیک، بهینه‌سازی Technical SEO'
  },
  {
    year: 'فروردین ۱۴۰۰ – فروردین ۱۴۰۱',
    title: 'کارشناس سئو',
    company: 'بیتستان | تهران',
    description: 'رساندن ۱۵ کلیدواژه رقابتی حوزه رمزارز به صفحه نخست نتایج گوگل طی ۴ ماه. افزایش ۵۰٪ ترافیک ارگانیک با استراتژی محتوایی و بهینه‌سازی ساختاری.',
    achievement: '۱۵ کلمه در صفحه اول گوگل، رشد ۵۰٪ ترافیک ارگانیک، استراتژی محتوایی'
  }
];

export const OTHER_COLLABORATIONS = [
  { company: 'ورسئلند', role: 'کارشناس ارشد دیجیتال مارکتینگ' },
  { company: 'سازیتو', role: 'کارشناس سئو' },
  { company: 'گیشه ۷', role: 'کارشناس سئو' },
  { company: 'آرتیالس', role: 'کارشناس شبکه‌های اجتماعی' },
  { company: 'رسپینا ۲۴', role: 'کارشناس تولید محتوا' }
];

export const SELECT_PROJECTS = [
  { title: 'مدیر وب‌سایت امیر اپتیک', desc: 'پیاده‌سازی Data Tracking و بهینه‌سازی SEO/UX برای رشد نرخ تبدیل', date: 'شهریور ۱۴۰۴' },
  { title: 'کارشناس گوگل ادز — Hihotel', desc: 'بازطراحی ساختار کمپین‌ها برای بهبود کیفیت ترافیک و بازده تبلیغات', date: 'فروردین ۱۴۰۴' },
  { title: 'اینفلوئنسر مارکتینگ — دژینو', desc: 'بهینه‌سازی فرآیند همکاری با اینفلوئنسرها؛ ROI تقریباً دوبرابر', date: 'اردیبهشت ۱۴۰۳' },
  { title: 'کارشناس سئو — امیدارویزا', desc: 'بهینه‌سازی +۱۵۰ صفحه و بهبود CTR نتایج جستجو برای رشد ارگانیک', date: 'آبان ۱۴۰۲' },
  { title: 'سرپرست سئو — پارتوکا', desc: 'استراتژی SEO شش سایت و +۸۰ محتوا؛ زیرساخت رشد ارگانیک مقیاس‌پذیر', date: 'مرداد ۱۴۰۰' },
  { title: 'طراحی سایت فضانورد', desc: 'راه‌اندازی fazanavard.app؛ زیرساخت اولیه محصول برای توسعه آتی', date: 'آبان ۱۴۰۳' }
];

export const EDUCATION_AND_COURSES = {
  education: [
    { title: 'دیپلم IT — امنیت اطلاعات', institute: 'خوارزمی غیرانتفاعی', year: '۱۳۹۷', grade: 'معدل ۱۸' }
  ],
  courses: [
    { title: 'سئو حرفه‌ای', provider: 'آکادمی وبسیما', date: 'شهریور ۱۳۹۹' },
    { title: 'پرفورمنس مارکتینگ', provider: 'آنالیتیپس', date: 'شهریور ۱۴۰۳' },
    { title: 'دوره میداس (CRO)', provider: 'آنالیتیپس', date: 'اردیبهشت ۱۴۰۴' }
  ]
};

export const HOW_I_WORK_STEPS = [
  {
    step: '۰۱',
    title: 'ارزیابی ترکینگ و ممیزی داده‌ها (Audit)',
    desc: 'بررسی سلامت ترکینگ، شناسایی هدررفت بودجه، نقاط افت Funnel و سنجش وضعیت رقبای کلیدی.',
    icon: 'target'
  },
  {
    step: '۰۲',
    title: 'فرضیه‌سازی و نقشه راه A/B تست',
    desc: 'تعریف دقیق KPIها، فرضیه‌سازی حل مشکلات UX و ساخت ساختارهای هوشمند بیدینگ و تبلیغاتی.',
    icon: 'laptop'
  },
  {
    step: '۰۳',
    title: 'اجرای کمپین‌ها و تست‌های ساختاریافته',
    desc: 'راه‌اندازی کمپین‌های آزمایشی، تست A/B صفحات و ارزیابی کیفیت ورودی‌ها با سیستم‌های Scoring.',
    icon: 'rocket'
  },
  {
    step: '۰۴',
    title: 'بهینه‌سازی مستمر و اسکیل نتایج',
    desc: 'تکرار و گسترش موفقیت‌ها، اسکیل بودجه کانال‌های با بازدهی بالا و ارائه گزارش‌های داده‌محور و شفاف.',
    icon: 'chart'
  }
];
