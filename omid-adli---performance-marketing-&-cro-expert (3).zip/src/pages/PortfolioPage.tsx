import React, { useState } from 'react';
import { Theme, Page, CaseStudy } from '../types';
import { CASE_STUDIES } from '../data/content';
import { IconBadge3D } from '../components/3D/3DIconBadge';
import { PageHeader } from '../components/PageHeader';
import { ArrowUpLeft, ChevronLeft, Filter, CheckCircle2, TrendingUp, X, Sparkles, AlertTriangle, Lightbulb } from 'lucide-react';

interface PortfolioPageProps {
  theme: Theme;
  onNavigate: (page: Page) => void;
  selectedCaseStudy: CaseStudy | null;
  onSelectCaseStudy: (study: CaseStudy | null) => void;
}

export const PortfolioPage: React.FC<PortfolioPageProps> = ({
  theme,
  onNavigate,
  selectedCaseStudy,
  onSelectCaseStudy
}) => {
  const isDark = theme === 'dark';
  const [filter, setFilter] = useState<string>('All');

  const categories = ['All', 'Crypto', 'Travel', 'E-commerce', 'SaaS'];

  const filteredStudies = filter === 'All' 
    ? CASE_STUDIES 
    : CASE_STUDIES.filter(s => s.industry === filter);

  return (
    <div className="space-y-12 py-4">
      {/* Top Page Header & Breadcrumb */}
      <PageHeader
        theme={theme}
        page="portfolio"
        title="نتایج اثبات‌شده و کیس‌استاندی‌های واقعی"
        subtitle="بررسی دقیق چالش‌ها، راهکارهای بازطراحی لندینگ پیج و نتایج عددی قبل و بعد در پروژه‌های پیشرو."
        badgeText="نمونه‌کارهای اختصاصی"
        onNavigate={onNavigate}
      />

      {/* Filter Pills */}
      <div className="flex flex-wrap items-center justify-center gap-2 max-w-2xl mx-auto">
        {categories.map((cat) => {
          const active = filter === cat;
          return (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all duration-300 ${
                active
                  ? 'bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white shadow-lg shadow-blue-500/25'
                  : isDark 
                    ? 'bg-white/10 text-slate-300 hover:bg-white/20 hover:text-white' 
                    : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200 shadow-sm'
              }`}
            >
              {cat === 'All' ? 'همه صنایع' : cat}
            </button>
          );
        })}
      </div>

      {/* Portfolio Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredStudies.map((study) => (
          <div
            key={study.id}
            onClick={() => onSelectCaseStudy(study)}
            className={`p-7 rounded-[36px] cursor-pointer transition-all duration-300 flex flex-col justify-between group ${
              isDark ? 'glass-card-dark glass-card-dark-hover' : 'glass-card-light glass-card-light-hover'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="px-3.5 py-1 rounded-full text-[11px] font-bold bg-[#8b5cf6]/15 border border-[#8b5cf6]/30 text-[#8b5cf6]">
                  {study.industryFa}
                </span>
                <IconBadge3D iconName={study.thumbnailIcon} theme={theme} size="sm" glowColor="cyan" floating={false} />
              </div>

              <h2 className={`text-lg font-black mb-3 group-hover:text-[#5ce1e6] transition-colors leading-snug ${
                isDark ? 'text-white' : 'text-[#1a1240]'
              }`}>
                {study.title}
              </h2>

              <p className={`text-xs leading-relaxed mb-6 line-clamp-3 ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                {study.summary}
              </p>

              {/* Before/After Metrics Glow Cards */}
              <div className="grid grid-cols-3 gap-2 p-3.5 rounded-2xl bg-black/25 border border-white/10 mb-6">
                <div className="text-center">
                  <span className="text-[10px] text-slate-400 block">ROAS</span>
                  <span className="text-xs font-black text-emerald-400 dir-ltr">{study.metrics.roas}</span>
                </div>
                <div className="text-center border-x border-white/10">
                  <span className="text-[10px] text-slate-400 block">نرخ تبدیل</span>
                  <span className="text-xs font-black text-[#5ce1e6] dir-ltr">{study.metrics.conversionRate}</span>
                </div>
                <div className="text-center">
                  <span className="text-[10px] text-slate-400 block">کاهش CAC</span>
                  <span className="text-xs font-black text-[#8b5cf6] dir-ltr">{study.metrics.cacReduction}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 text-xs font-bold text-[#5ce1e6] group-hover:text-white transition-colors">
              <span>بررسی کامل کیس‌استاندی</span>
              <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>

      {/* CASE STUDY DETAIL MODAL LAYOUT */}
      {selectedCaseStudy && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/80 backdrop-blur-xl animate-fade-in">
          <div className={`relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-[40px] p-6 sm:p-10 border shadow-2xl my-auto ${
            isDark ? 'bg-[#1a1240] border-white/20 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            {/* Close Button */}
            <button
              onClick={() => onSelectCaseStudy(null)}
              className="absolute top-6 left-6 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Case Study Header */}
            <div className="space-y-4 pt-2 pb-6 border-b border-white/10">
              <div className="flex flex-wrap items-center gap-3">
                <span className="px-3.5 py-1 rounded-full text-xs font-black bg-[#8b5cf6]/20 text-[#8b5cf6] border border-[#8b5cf6]/40">
                  {selectedCaseStudy.industryFa}
                </span>
                <span className="text-xs text-slate-400 font-mono">مشتری: {selectedCaseStudy.client}</span>
              </div>

              <h2 className="text-2xl sm:text-4xl font-black leading-tight">
                {selectedCaseStudy.title}
              </h2>
            </div>

            {/* 3-Column Challenge / Solution / Results Layout */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-8">
              {/* Challenge */}
              <div className="p-6 rounded-3xl bg-red-500/10 border border-red-500/20 space-y-3">
                <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
                  <AlertTriangle className="w-5 h-5" />
                  <span>چالش اولیه</span>
                </div>
                <p className="text-xs leading-relaxed text-slate-300">
                  {selectedCaseStudy.challenge}
                </p>
              </div>

              {/* Solution */}
              <div className="p-6 rounded-3xl bg-blue-500/10 border border-blue-500/20 space-y-3">
                <div className="flex items-center gap-2 text-[#4c8dff] font-bold text-sm">
                  <Lightbulb className="w-5 h-5" />
                  <span>راهکار پیاده‌شده</span>
                </div>
                <p className="text-xs leading-relaxed text-slate-300">
                  {selectedCaseStudy.solution}
                </p>
              </div>

              {/* Results */}
              <div className="p-6 rounded-3xl bg-emerald-500/10 border border-emerald-500/20 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                  <TrendingUp className="w-5 h-5" />
                  <span>نتایج حاصله</span>
                </div>
                <p className="text-xs leading-relaxed text-slate-300">
                  {selectedCaseStudy.results}
                </p>
              </div>
            </div>

            {/* Before vs After Metric Comparison Table/Grid */}
            <div className="space-y-4 my-8">
              <h3 className="font-black text-lg border-r-4 border-[#8b5cf6] pr-3">
                مقایسه دقیق شاخص‌ها (قبل و بعد از پروژه)
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {selectedCaseStudy.metricsComparison.map((metric, idx) => (
                  <div key={idx} className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                    <span className="text-xs text-slate-400 font-bold block">{metric.label}</span>
                    <div className="flex items-center justify-between pt-1">
                      <div>
                        <span className="text-[10px] text-slate-500 block">قبل</span>
                        <span className="text-sm font-bold text-red-400 dir-ltr">{metric.before}</span>
                      </div>
                      <div className="text-slate-500">←</div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">بعد</span>
                        <span className="text-sm font-extrabold text-emerald-400 dir-ltr">{metric.after}</span>
                      </div>
                    </div>
                    <div className="pt-2 text-center text-xs font-black text-[#5ce1e6]">
                      رشد: {metric.growth}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <button
                onClick={() => {
                  onSelectCaseStudy(null);
                  onNavigate('contact');
                }}
                className="w-full sm:w-auto glow-btn px-8 py-3.5 rounded-full text-xs font-bold text-white flex items-center justify-center gap-2"
              >
                <span>درخواست پروژه مشابه برای شما</span>
                <ArrowUpLeft className="w-4 h-4" />
              </button>

              <button
                onClick={() => onSelectCaseStudy(null)}
                className="px-6 py-3 rounded-full bg-white/10 hover:bg-white/20 text-xs font-bold text-white"
              >
                بستن کیس‌استاندی
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
