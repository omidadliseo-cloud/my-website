import React, { useState } from 'react';
import { Theme, Page } from '../types';
import { PERSONAL_INFO } from '../data/content';
import { BookingCalendar } from '../components/BookingCalendar';
import { PageHeader } from '../components/PageHeader';
import { Send, Mail, Linkedin, PhoneCall, CheckCircle2, Clock, MapPin, Sparkles, ArrowUpLeft, ShieldCheck } from 'lucide-react';

interface ContactPageProps {
  theme: Theme;
  onNavigate: (page: Page) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ theme, onNavigate }) => {
  const isDark = theme === 'dark';
  const [activeTab, setActiveTab] = useState<'form' | 'calendar'>('form');
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phoneOrTelegram: '',
    budget: '$3,000 - $10,000',
    serviceNeeded: 'مدیریت کمپین و تبلیغات (Paid Ads)',
    details: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="space-y-12 py-4">
      {/* Top Page Header & Breadcrumb */}
      <PageHeader
        theme={theme}
        page="contact"
        title="ارتباط مستقیم و ثبت درخواست مشاوره"
        subtitle="فرم زیر را تکمیل کنید یا از تقویم آنلاین زمان جلسه Google Meet خود را رزرو کنید."
        badgeText="شروع پروژه و همکاری"
        onNavigate={onNavigate}
      />

      <div className="text-center">
        {/* Tab Selector Buttons */}
        <div className="inline-flex p-1.5 rounded-full bg-black/20 border border-white/10 gap-2">
          <button
            onClick={() => setActiveTab('form')}
            className={`px-6 py-2.5 rounded-full text-xs font-bold transition-all ${
              activeTab === 'form'
                ? 'bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white shadow-lg shadow-blue-500/25'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            فرم درخواست مشاوره
          </button>
          <button
            onClick={() => setActiveTab('calendar')}
            className={`px-6 py-2.5 rounded-full text-xs font-bold transition-all ${
              activeTab === 'calendar'
                ? 'bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white shadow-lg shadow-blue-500/25'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            رزرو آنلاین جلسه میت
          </button>
        </div>
      </div>

      {activeTab === 'calendar' ? (
        <div className="max-w-3xl mx-auto">
          <BookingCalendar theme={theme} />
        </div>
      ) : (
        /* Split Layout */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Side: Direct Contact Chips & Availability */}
          <div className="lg:col-span-5 space-y-6">
          {/* Availability Glass Badge */}
          <div className={`p-6 rounded-[32px] border ${
            isDark ? 'glass-card-dark' : 'glass-card-light'
          }`}>
            <div className="flex items-center gap-3 mb-3">
              <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
              <h3 className={`font-black text-base ${isDark ? 'text-white' : 'text-[#1a1240]'}`}>
                وضعیت پذیرش پروژه
              </h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              {PERSONAL_INFO.availability}
            </p>
            <div className="text-[11px] text-slate-400 flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-[#5ce1e6]" />
              <span>میانگین زمان پاسخ‌گویی: کمتر از ۴ ساعت کاری</span>
            </div>
          </div>

          {/* Direct Contact Options */}
          <div className="space-y-3">
            <h3 className={`font-bold text-sm border-r-2 border-[#8b5cf6] pr-2 ${isDark ? 'text-white' : 'text-[#1a1240]'}`}>
              ارتباط سریع‌تر در پیام‌رسان‌ها
            </h3>

            <a
              href={`https://t.me/${PERSONAL_INFO.telegram.replace('@', '')}`}
              target="_blank"
              rel="noreferrer"
              className={`p-4 rounded-2xl border transition-all duration-300 flex items-center justify-between group ${
                isDark ? 'bg-white/5 border-white/10 hover:border-[#5ce1e6]/50' : 'bg-white border-slate-200 shadow-sm hover:border-indigo-400'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-[#5ce1e6]/20 text-[#5ce1e6]">
                  <Send className="w-5 h-5" />
                </div>
                <div>
                  <h4 className={`font-bold text-xs ${isDark ? 'text-white' : 'text-[#1a1240]'}`}>آیدی تلگرام مستقیم</h4>
                  <p className="text-[11px] text-slate-400 dir-ltr text-right">{PERSONAL_INFO.telegram}</p>
                </div>
              </div>
              <ArrowUpLeft className="w-4 h-4 text-slate-400 group-hover:text-[#5ce1e6] group-hover:-translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>

            <a
              href={`mailto:${PERSONAL_INFO.email}`}
              className={`p-4 rounded-2xl border transition-all duration-300 flex items-center justify-between group ${
                isDark ? 'bg-white/5 border-white/10 hover:border-[#8b5cf6]/50' : 'bg-white border-slate-200 shadow-sm hover:border-violet-400'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-[#8b5cf6]/20 text-[#8b5cf6]">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className={`font-bold text-xs ${isDark ? 'text-white' : 'text-[#1a1240]'}`}>ارسال ایمیل مستقیم</h4>
                  <p className="text-[11px] text-slate-400 dir-ltr text-right">{PERSONAL_INFO.email}</p>
                </div>
              </div>
              <ArrowUpLeft className="w-4 h-4 text-slate-400 group-hover:text-[#8b5cf6] group-hover:-translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>

            <a
              href={PERSONAL_INFO.linkedin}
              target="_blank"
              rel="noreferrer"
              className={`p-4 rounded-2xl border transition-all duration-300 flex items-center justify-between group ${
                isDark ? 'bg-white/5 border-white/10 hover:border-[#4c8dff]/50' : 'bg-white border-slate-200 shadow-sm hover:border-blue-400'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-[#4c8dff]/20 text-[#4c8dff]">
                  <Linkedin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className={`font-bold text-xs ${isDark ? 'text-white' : 'text-[#1a1240]'}`}>پروفایل لینکدین</h4>
                  <p className="text-[11px] text-slate-400 dir-ltr text-right">Omid Adli</p>
                </div>
              </div>
              <ArrowUpLeft className="w-4 h-4 text-slate-400 group-hover:text-[#4c8dff] group-hover:-translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>
          </div>

          {/* Timezone / Location Info */}
          <div className="p-5 rounded-2xl bg-black/20 border border-white/10 space-y-2 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#8b5cf6]" />
              <span>موقعیت مکانی: {PERSONAL_INFO.location} (GMT+3:30)</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>قرارداد رسمی عدم افشای اطلاعات (NDA) محفوظ است.</span>
            </div>
          </div>
        </div>

        {/* Right Side: Contact Form Glass Panel */}
        <div className="lg:col-span-7">
          <div className={`p-8 sm:p-10 rounded-[40px] border backdrop-blur-2xl shadow-2xl ${
            isDark ? 'glass-card-dark' : 'glass-card-light'
          }`}>
            <h2 className={`text-2xl font-black mb-6 ${isDark ? 'text-white' : 'text-[#1a1240]'}`}>
              فرم درخواست مشاوره و ممیزی کمپین
            </h2>

            {submitted ? (
              <div className="p-8 rounded-3xl bg-emerald-500/20 border border-emerald-500/40 text-center space-y-4">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                <h3 className="text-xl font-bold text-white">پیام شما با موفقیت دریافت شد!</h3>
                <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                  با تشکر از اعتماد شما. درخواست شما بررسی شده و تا حداکثر ۴ ساعت آینده از طریق پیام‌رسان یا ایمیل با شما تماس خواهم گرفت.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-6 py-2.5 rounded-full bg-white/10 text-xs font-bold text-white hover:bg-white/20"
                >
                  ارسال پیام دیگر
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-xs font-bold mb-2 text-slate-300">نام و نام خانوادگی *</label>
                    <input
                      type="text"
                      required
                      placeholder="مثلا: علی رضایی"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={`w-full py-3.5 px-4 rounded-2xl text-xs font-bold border focus:outline-none ${
                        isDark ? 'bg-white/10 border-white/15 text-white placeholder-slate-500 focus:border-[#8b5cf6]' : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-indigo-500'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold mb-2 text-slate-300">آدرس ایمیل کاری *</label>
                    <input
                      type="email"
                      required
                      placeholder="name@company.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className={`w-full py-3.5 px-4 rounded-2xl text-xs font-bold border focus:outline-none ${
                        isDark ? 'bg-white/10 border-white/15 text-white placeholder-slate-500 focus:border-[#8b5cf6]' : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-indigo-500'
                      }`}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-xs font-bold mb-2 text-slate-300">شماره تماس یا آیدی تلگرام *</label>
                    <input
                      type="text"
                      required
                      placeholder="@telegram_id یا 0912..."
                      value={formData.phoneOrTelegram}
                      onChange={(e) => setFormData({ ...formData, phoneOrTelegram: e.target.value })}
                      className={`w-full py-3.5 px-4 rounded-2xl text-xs font-bold border focus:outline-none ${
                        isDark ? 'bg-white/10 border-white/15 text-white placeholder-slate-500 focus:border-[#8b5cf6]' : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-indigo-500'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold mb-2 text-slate-300">بودجه تبلیغات ماهانه مد نظر</label>
                    <select
                      value={formData.budget}
                      onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                      className={`w-full py-3.5 px-4 rounded-2xl text-xs font-bold border focus:outline-none ${
                        isDark ? 'bg-[#1a1240] border-white/15 text-white focus:border-[#8b5cf6]' : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-indigo-500'
                      }`}
                    >
                      <option value="زیر $2,000">زیر $۲,۰۰۰ ماهانه</option>
                      <option value="$2,000 - $5,000">$۲,۰۰۰ تا $۵,۰۰۰ ماهانه</option>
                      <option value="$5,000 - $15,000">$۵,۰۰۰ تا $۱۵,۰۰۰ ماهانه</option>
                      <option value="بالای $15,000">بالای $۱۵,۰۰۰ (سازمانی)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold mb-2 text-slate-300">نوع سرویس مورد نیاز</label>
                  <select
                    value={formData.serviceNeeded}
                    onChange={(e) => setFormData({ ...formData, serviceNeeded: e.target.value })}
                    className={`w-full py-3.5 px-4 rounded-2xl text-xs font-bold border focus:outline-none ${
                      isDark ? 'bg-[#1a1240] border-white/15 text-white focus:border-[#8b5cf6]' : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-indigo-500'
                    }`}
                  >
                    <option value="مدیریت کمپین و تبلیغات (Paid Ads)">مدیریت کمپین و تبلیغات (Paid Ads)</option>
                    <option value="بهینه‌سازی نرخ تبدیل و لندینگ (CRO)">بهینه‌سازی نرخ تبدیل و لندینگ (CRO)</option>
                    <option value="پیاده‌سازی ترکینگ و آنالیتیکس (GA4/GTM)">پیاده‌سازی ترکینگ و آنالیتیکس (GA4/GTM)</option>
                    <option value="مشاوره جامع ۳۶۰ درجه رشد">مشاوره جامع ۳۶۰ درجه رشد</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold mb-2 text-slate-300">توضیحات مختصر درباره کسب‌وکار و آدرس وب‌سایت</label>
                  <textarea
                    rows={4}
                    placeholder="توضیح کوتاه در مورد چالش فعلی، لینک سایت یا پیج اینستاگرام..."
                    value={formData.details}
                    onChange={(e) => setFormData({ ...formData, details: e.target.value })}
                    className={`w-full p-4 rounded-2xl text-xs font-bold border focus:outline-none ${
                      isDark ? 'bg-white/10 border-white/15 text-white placeholder-slate-500 focus:border-[#8b5cf6]' : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-indigo-500'
                    }`}
                  />
                </div>

                <button
                  type="submit"
                  className="w-full glow-btn py-4 rounded-2xl text-xs font-bold text-white flex items-center justify-center gap-2 cursor-pointer shadow-xl"
                >
                  <span>ثبت درخواست و ارسال پیام</span>
                  <ArrowUpLeft className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
      )}
    </div>
  );
};
