import React, { useState } from 'react';
import { Theme, Page, CaseStudy } from '../types';
import { SERVICES, CASE_STUDIES, STATS } from '../data/content';
import { IsometricDashboard } from '../components/3D/IsometricDashboard';
import { HeroSlider } from '../components/HeroSlider';
import { IconBadge3D } from '../components/3D/3DIconBadge';
import { FAQSection } from '../components/FAQSection';
import { ResumeModal } from '../components/ResumeModal';
import { ChevronLeft, Calendar, ArrowUpLeft } from 'lucide-react';

interface HomePageProps {
  theme: Theme;
  onNavigate: (page: Page) => void;
  onSelectCaseStudy: (caseStudy: CaseStudy) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ theme, onNavigate, onSelectCaseStudy }) => {
  const isDark = theme === 'dark';
  const [showResume, setShowResume] = useState(false);

  return (
    <div className="space-y-24 md:space-y-32 py-8">
      {/* 1. HERO SECTION */}
      <section className="relative pt-6 pb-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Right Column: Copywriting Slider & CTAs (RTL) */}
          <div className="lg:col-span-7 text-right">
            <HeroSlider 
              theme={theme} 
              onNavigate={onNavigate} 
              onOpenResume={() => setShowResume(true)} 
            />
          </div>

          {/* Left Column: 3D Interactive Laptop Illustration */}
          <div className="lg:col-span-5">
            <IsometricDashboard theme={theme} />
          </div>
        </div>
      </section>

      {/* 2. STATS STRIP */}
      <section className="relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {STATS.map((stat, idx) => (
            <div
              key={idx}
              className={`p-6 sm:p-8 rounded-[28px] transition-all duration-300 relative overflow-hidden group ${
                isDark ? 'glass-card-dark glass-card-dark-hover' : 'glass-card-light glass-card-light-hover'
              }`}
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-[#8b5cf6]/20 to-transparent rounded-bl-full pointer-events-none group-hover:scale-150 transition-transform duration-500" />

              <div className="text-3xl sm:text-4xl lg:text-5xl font-black gradient-text mb-2 dir-ltr text-right">
                {stat.value}
              </div>

              <div className={`font-bold text-sm sm:text-base mb-1 ${isDark ? 'text-white' : 'text-[#1a1240]'}`}>
                {stat.label}
              </div>

              <div className="text-xs text-slate-400 font-medium">
                {stat.subtext}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. WHAT I DO SECTION (3 Glass Cards with 3D Icons) */}
      <section className="space-y-12">
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <div className="inline-block px-4 py-1.5 rounded-full bg-gradient-to-r from-[#8b5cf6]/20 to-[#4c8dff]/20 border border-[#8b5cf6]/30 text-xs font-extrabold text-[#8b5cf6]">
            خدمات اختصاصی
          </div>
          <h2 className={`text-3xl sm:text-4xl font-black ${isDark ? 'text-white' : 'text-[#1a1240]'}`}>
            چگونه به رشد سریع کسب‌وکار شما کمک می‌کنم؟
          </h2>
          <p className={`text-sm sm:text-base ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
            تمرکز من بر سه ستون اصلی مارکتینگ پاداش‌محور است: جلب ترافیک هدفمند، تبدیل کاربر و ترکینگ دقیق داده‌ها.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {SERVICES.slice(0, 3).map((service, idx) => (
            <div
              key={service.id}
              className={`p-8 rounded-[32px] flex flex-col justify-between transition-all duration-300 relative group ${
                isDark ? 'glass-card-dark glass-card-dark-hover' : 'glass-card-light glass-card-light-hover'
              }`}
            >
              <div>
                <div className="mb-6 flex items-center justify-between">
                  <IconBadge3D
                    iconName={service.iconName}
                    theme={theme}
                    size="lg"
                    glowColor={idx === 0 ? 'magenta' : idx === 1 ? 'cyan' : 'blue'}
                  />
                  <span className="text-3xl font-black opacity-20 font-mono">0{idx + 1}</span>
                </div>

                <h3 className={`text-xl font-black mb-3 ${isDark ? 'text-white' : 'text-[#1a1240]'}`}>
                  {service.title}
                </h3>

                <p className={`text-sm leading-relaxed mb-6 ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                  {service.shortDesc}
                </p>

                <ul className="space-y-2 mb-8 text-xs text-slate-300">
                  {service.features.slice(0, 3).map((feat, fIdx) => (
                    <li key={fIdx} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#5ce1e6]" />
                      <span className={isDark ? 'text-slate-300' : 'text-slate-700'}>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                onClick={() => onNavigate('services')}
                className="w-full py-3 rounded-2xl bg-white/5 hover:bg-gradient-to-r hover:from-[#1d4ed8] hover:to-[#3b82f6] border border-white/10 text-xs font-bold text-white transition-all duration-300 flex items-center justify-center gap-2 group-hover:border-transparent"
              >
                <span>مشاهده جزئیات کامل</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* 4. FEATURED PORTFOLIO PREVIEW */}
      <section className="space-y-12">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-extrabold text-[#5ce1e6] uppercase tracking-wider">نتایج واقعی</span>
            <h2 className={`text-3xl sm:text-4xl font-black mt-2 ${isDark ? 'text-white' : 'text-[#1a1240]'}`}>
              کیس‌استاندی‌ها و نمونه‌کارهای برتر
            </h2>
          </div>

          <button
            onClick={() => onNavigate('portfolio')}
            className={`px-6 py-3 rounded-full text-xs font-bold border transition-all flex items-center gap-2 ${
              isDark ? 'bg-white/10 border-white/20 text-white hover:bg-white/20' : 'bg-white border-slate-300 text-slate-800 hover:bg-slate-50'
            }`}
          >
            <span>مشاهده همه پروژه‌ها</span>
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {CASE_STUDIES.filter(c => c.featured).slice(0, 3).map((study) => (
            <div
              key={study.id}
              onClick={() => onSelectCaseStudy(study)}
              className={`p-7 rounded-[32px] cursor-pointer transition-all duration-300 flex flex-col justify-between group ${
                isDark ? 'glass-card-dark glass-card-dark-hover' : 'glass-card-light glass-card-light-hover'
              }`}
            >
              <div>
                {/* Industry Tag & Icon Header */}
                <div className="flex items-center justify-between mb-4">
                  <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-[#8b5cf6]/15 border border-[#8b5cf6]/30 text-[#8b5cf6]">
                    {study.industryFa}
                  </span>
                  <IconBadge3D iconName={study.thumbnailIcon} theme={theme} size="sm" glowColor="blue" floating={false} />
                </div>

                <h3 className={`text-lg font-black mb-3 group-hover:text-[#5ce1e6] transition-colors leading-snug ${
                  isDark ? 'text-white' : 'text-[#1a1240]'
                }`}>
                  {study.title}
                </h3>

                <p className={`text-xs leading-relaxed mb-6 line-clamp-3 ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                  {study.summary}
                </p>

                {/* Key Metrics Highlight Strip */}
                <div className="grid grid-cols-3 gap-2 p-3.5 rounded-2xl bg-black/20 border border-white/10 mb-6">
                  <div className="text-center">
                    <span className="text-[10px] text-slate-400 block">ROAS</span>
                    <span className="text-xs font-black text-emerald-400 dir-ltr">{study.metrics.roas}</span>
                  </div>
                  <div className="text-center border-x border-white/10">
                    <span className="text-[10px] text-slate-400 block">نرخ تبدیل</span>
                    <span className="text-xs font-black text-[#5ce1e6] dir-ltr">{study.metrics.conversionRate}</span>
                  </div>
                  <div className="text-center">
                    <span className="text-[10px] text-slate-400 block">کاهش CAC</span>
                    <span className="text-xs font-black text-[#8b5cf6] dir-ltr">{study.metrics.cacReduction}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 text-xs font-bold text-[#5ce1e6] group-hover:text-white transition-colors">
                <span>مطالعه کامل کیس‌استاندی</span>
                <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5.5. FAQ SECTION */}
      <FAQSection theme={theme} />

      {/* 6. FINAL CTA BANNER */}
      <section className="relative z-10">
        <div className="p-8 sm:p-14 rounded-[40px] bg-gradient-to-r from-[#1a1240] via-[#2d1b5e] to-[#0f0a2e] border border-white/20 text-center space-y-6 shadow-[0_25px_70px_rgba(139,92,246,0.25)] relative overflow-hidden">
          <div className="absolute -top-20 -left-20 w-64 h-64 bg-[#8b5cf6]/30 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-[#4c8dff]/30 rounded-full blur-3xl pointer-events-none" />

          <h2 className="text-3xl sm:text-5xl font-black text-white leading-tight max-w-2xl mx-auto">
            آماده جهش فروش و کاهش هزینه‌های تبلیغات خود هستید؟
          </h2>

          <p className="text-slate-300 text-sm sm:text-base max-w-xl mx-auto">
            همین امروز جلسه‌ ۳۰ دقیقه‌ای مشاوره استراتژیک رایگان رزرو کنید تا وضعیت فعلی کمپین‌ها و لندینگ پیج شما را تحلیل کنیم.
          </p>

          <div className="pt-2">
            <button
              onClick={() => onNavigate('contact')}
              className="glow-btn px-10 py-5 rounded-full text-base font-black text-white inline-flex items-center gap-3 shadow-2xl cursor-pointer hover:scale-105 transition-transform"
            >
              <span>رزرو مشاوره استراتژیک رایگان</span>
              <ArrowUpLeft className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Resume Modal */}
      {showResume && (
        <ResumeModal theme={theme} onClose={() => setShowResume(false)} />
      )}
    </div>
  );
};

