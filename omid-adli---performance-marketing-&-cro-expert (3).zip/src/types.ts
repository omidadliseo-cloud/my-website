export type Theme = 'dark' | 'light';
export type Page = 'home' | 'services' | 'portfolio' | 'about' | 'blog' | 'contact';

export interface ServiceItem {
  id: string;
  title: string;
  titleEn: string;
  iconName: string;
  shortDesc: string;
  fullDesc: string;
  features: string[];
  deliverables: string[];
  tags: string[];
}

export interface MetricComparison {
  label: string;
  before: string;
  after: string;
  growth: string;
}

export interface CaseStudy {
  id: string;
  title: string;
  client: string;
  industry: 'Fintech' | 'Crypto' | 'Travel' | 'E-commerce' | 'SaaS';
  industryFa: string;
  summary: string;
  thumbnailIcon: string;
  heroColor: string;
  featured: boolean;
  metrics: {
    roas: string;
    conversionRate: string;
    cacReduction: string;
  };
  metricsComparison: MetricComparison[];
  challenge: string;
  solution: string;
  results: string;
  tags: string[];
  date: string;
}

export interface Testimonial {
  id: string;
  clientName: string;
  clientRole: string;
  company: string;
  avatarUrl: string;
  rating: number;
  quote: string;
  metricHighlight: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  categoryFa: string;
  date: string;
  readTime: string;
  author: string;
  imageIcon: string;
  featured: boolean;
}

export interface SkillTool {
  name: string;
  category: 'Ads' | 'Analytics' | 'CRO' | 'Tech';
  icon: string;
  proficiency: number;
}

export interface TimelineMilestone {
  year: string;
  title: string;
  company: string;
  description: string;
  achievement: string;
}
